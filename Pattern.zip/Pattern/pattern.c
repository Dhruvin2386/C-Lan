#include<stdio.h>
int main(){

    // question-1
    printf("\nQuestion-1\n\n");
    printf("Name :- Dhruvin\n");
    printf("Age :- 20\n");
    printf("School :- Aspire public school\n");

    // question-2
    printf("\nQuestion-2\n\n");
    printf("  -  -  -  -  -  \n");
    printf("|               |\n");
    printf("|               |\n");
    printf("|     NAME      |\n");
    printf("|               |\n");
    printf("|               |\n");
    printf("  -  -  -  -  -  \n");

    // question-3
    printf("\nQuestion-3\n\n");
    printf(" -  -  -\n");
    printf("|       |\n");
    printf("N       |\n");
    printf("A       |\n");
    printf("M       |\n");
    printf("E       |\n");
    printf("|       |\n");
    printf(" -  -  -\n");

    // question-4
    printf("\nQuestion-4\n\n");
    printf("*\n");
    printf("* *\n");
    printf("* * *\n");
    printf("* *\n");
    printf("*\n");

    // question-5
    printf("\nQuestion-5\n\n");
    printf("*\n");
    printf("*\n");
    printf("*                             * *\n");
    printf("*                           *     *\n");
    printf("*        *  *             *\n");
    printf("*      *      *          *\n");
    printf("*    *          *      *\n");
    printf("*  *              *  *\n");
    printf("*\n");

    // question-6
    printf("\nQuestion-6\n\n");
    printf("*  *  *  *  *\n\n");
    printf("*           *\n\n");
    printf("*  *  *  *  *\n\n");
    printf("*           *\n\n");
    printf("*           *\n\n");
    printf("*           *\n\n");
    printf("*           *\n\n");

    // question-7
    printf("\nQuestion-7\n\n");
    printf("*  *  *\n\n");
    printf("*       *\n\n");
    printf("*      *\n\n");
    printf("*  *  *\n\n");
    printf("*       *\n\n");
    printf("*      *\n\n");
    printf("*  *  *\n\n");

    // question-8
    printf("\nQuestion-8\n\n");
    printf("*  *  *  *\n\n");
    printf("*\n\n");
    printf("*\n\n");
    printf("*\n\n");
    printf("*\n\n");
    printf("*\n\n");
    printf("*  *  *  *\n\n");

    // question-9
    printf("\nQuestion-9\n\n");
    printf("*   *\n\n");
    printf("*      *\n\n");
    printf("*        *\n\n");
    printf("*         *\n\n");
    printf("*        *\n\n");
    printf("*      *\n\n");
    printf("*   *\n\n");

    // question-10
    printf("\nQuestion-10\n\n");
    printf("*  *  *  *\n\n");
    printf("*\n\n");
    printf("*\n\n");
    printf("*  *  *  *\n\n");
    printf("*\n\n");
    printf("*\n\n");
    printf("*  *  *  *\n\n");

    // question-11
    printf("\nQuestion-11\n\n");
    printf("*  *  *  *\n\n");
    printf("*\n\n");
    printf("*\n\n");
    printf("*  *  *  *\n\n");
    printf("*\n\n");
    printf("*\n\n");
    printf("*\n\n");

    // question-12
    printf("\nQuestion-12\n\n");
    printf("   *   *   *\n\n");
    printf("*             *\n\n");
    printf("*\n\n");
    printf("*       *  *  *\n\n");
    printf("*             *\n\n");
    printf("*             *\n\n");
    printf("   *   *   *\n\n");

    // question-13
    printf("\nQuestion-13\n\n");
    printf("*        *\n\n");
    printf("*        *\n\n");
    printf("*        *\n\n");
    printf("*  *  *  *\n\n");
    printf("*        *\n\n");
    printf("*        *\n\n");
    printf("*        *\n\n");

    // question-14
    printf("\nQuestion-14\n\n");
    printf("*  *  *  *  *\n\n");
    printf("      *\n\n");
    printf("      *\n\n");
    printf("      *\n\n");
    printf("      *\n\n");
    printf("      *\n\n");
    printf("*  *  *  *  *\n\n");

    // question-15
    printf("\nQuestion-15\n\n");
    printf(" *  *  *  *  *\n\n");
    printf("       *\n\n");
    printf("       *\n\n");
    printf("       *\n\n");
    printf("       *\n\n");
    printf("*      *\n\n");
    printf("  *   *\n\n");

    // question-16
    printf("\nQuestion-16\n\n");
    printf("*       *\n\n");
    printf("*     *\n\n");
    printf("*   *\n\n");
    printf("* *\n\n");
    printf("*   *\n\n");
    printf("*     *\n\n");
    printf("*       *\n\n");

    // question-17
    printf("\nQuestion-17\n\n");
    printf("*\n\n");
    printf("*\n\n");
    printf("*\n\n");
    printf("*\n\n");
    printf("*\n\n");
    printf("*\n\n");
    printf("*  *  *  *\n\n");

    // question-18
    printf("\nQuestion-18\n\n");
    printf("*         *\n\n");
    printf("*  *   *  *\n\n");
    printf("*    *    *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");

    // question-19
    printf("\nQuestion-19\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*  *      *\n\n");
    printf("*    *    *\n\n");
    printf("*      *  *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");

    // question-20
    printf("\nQuestion-20\n\n");printf("  *  *  *  \n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("  *  *  *  \n\n");

    // question-21
    printf("\nQuestion-21\n\n");
    printf("*  *  *  *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*  *  *  *\n\n");
    printf("*\n\n");
    printf("*\n\n");
    printf("*\n\n");

    // question-22
    printf("\nQuestion-22\n\n");
    printf("  *  *  *  \n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*    *    *\n\n");
    printf("*       *\n\n");
    printf("  *  *     *\n\n");

    // question-23
    printf("\nQuestion-23\n\n");
    printf("*   *  *\n\n");
    printf("*        *\n\n");
    printf("*       *\n\n");
    printf("*  *  *\n\n");
    printf("*       *\n\n");
    printf("*        *\n\n");
    printf("*         *\n\n");

    // question-24
    printf("\nQuestion-24\n\n");
    printf(" *  *  *  *\n\n");
    printf("*\n\n");
    printf("*\n\n");
    printf(" *  *  *\n\n");
    printf("          *\n\n");
    printf("          *\n\n");
    printf("*  *  *  *\n\n");

    // question-25
    printf("\nQuestion-25\n\n");
    printf("*  *  *  *  *\n\n");
    printf("      *\n\n");
    printf("      *\n\n");
    printf("      *\n\n");
    printf("      *\n\n");
    printf("      *\n\n");
    printf("      *\n\n");

    // question-26
    printf("\nQuestion-26\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("  *  *  *  \n\n");

    // question-27
    printf("\nQuestion-27\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("  *     *\n\n");
    printf("     *     \n\n");

    // question-28
    printf("\nQuestion-28\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*         *\n\n");
    printf("*    *    *\n\n");
    printf("*  *   *  *\n\n");
    printf("*         *\n\n");

    // question-29
    printf("\nQuestion-29\n\n");
    printf("*           *\n\n");
    printf("  *       *\n\n");
    printf("    *   *\n\n");
    printf("      *\n\n");
    printf("    *   *\n\n");
    printf("  *       *\n\n");
    printf("*           *\n\n");

    // question-30
    printf("\nQuestion-30\n\n");
    printf("*         *\n\n");
    printf(" *       *\n\n");
    printf("  *     *\n\n");
    printf("     *\n\n");
    printf("     *\n\n");
    printf("     *\n\n");
    printf("     *\n\n");

    // question-31
    printf("\nQuestion-31\n\n");
    printf("*  *  *  *  *\n\n");
    printf("          *\n\n");
    printf("        *\n\n");
    printf("      *\n\n");
    printf("    *\n\n");
    printf("  *\n\n");
    printf("*  *  *  *  *\n\n");

    return 0;
}